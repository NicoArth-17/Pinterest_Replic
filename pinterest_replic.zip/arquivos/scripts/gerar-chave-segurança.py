import secrets

# Gerando uma chave aleatória
print(secrets.token_hex(16)) # 16 bytes
